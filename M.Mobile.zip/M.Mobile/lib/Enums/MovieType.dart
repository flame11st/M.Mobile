enum MovieType {
    movie,
    tv
}