enum MovieListType {
    external,
    personal
}