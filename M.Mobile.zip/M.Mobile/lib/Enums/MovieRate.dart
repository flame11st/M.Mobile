class MovieRate {
    static const notRated = 0;
    static const liked = 1;
    static const notLiked = 2;
    static const addedToWatchlist = 4;
}