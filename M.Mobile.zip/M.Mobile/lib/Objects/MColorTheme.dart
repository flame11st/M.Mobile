import 'package:flutter/material.dart';

class MColorTheme {
  final Color primaryColor;
  final Color secondaryColor;
  final Color additionalColor;
  final Color fontsColor;

  MColorTheme(
      {this.primaryColor,
      this.secondaryColor,
      this.additionalColor,
      this.fontsColor});
}
